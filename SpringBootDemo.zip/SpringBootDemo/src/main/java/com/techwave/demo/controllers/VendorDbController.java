package com.techwave.demo.controllers;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.techwave.demo.Model.Vendordb;
import com.techwave.demo.dao.VendorDaoImpl;
import com.techwave.demo.repositories.VendorRepository;

@RestController
public class VendorDbController {
	@Autowired
	VendorDaoImpl vendorDaoImpl;
	@GetMapping("/getVendors")
	public List<Vendordb> getAllVendors()
	{
		List<Vendordb> list=vendorDaoImpl.getallVendors();
		
		return list;
	}
	@GetMapping("/getById/{vendorId}")
	public Vendordb getVendorById(@PathVariable("vendorId") int vendorId)
	{
		return vendorDaoImpl.getByVendorId(vendorId);
	}
	@GetMapping("/getByname/{name}")
	public List<Vendordb> getVendorById(@PathVariable("name") String name)
	{
		return vendorDaoImpl.getbyVendorName(name);
	}
	
	@GetMapping("/getByDate/{Dor}")
	public List<Vendordb> getVendorByDate(@PathVariable("Dor") String Dor)
	{
		return vendorDaoImpl.getbyDate(LocalDate.parse(Dor));
	}
	
	@PostMapping("/addVendor")
	public String addVendor(@RequestBody Vendordb V)
	{
		return vendorDaoImpl.InsertVendor(V);
	}
	@PutMapping("modifyVendor/{vendorId}")
	public String ModifyVendor(@RequestBody Vendordb V,@PathVariable("vendorId") int vendorId)
	{
		return vendorDaoImpl.UpdateVendor(V, vendorId);
	}
	@DeleteMapping("removeVendor/{vendorId}")
	public String removeVendor(@PathVariable("vendorId") int vendorId)
	{
		return vendorDaoImpl.DeleteVendor(vendorDaoImpl.getByVendorId(vendorId));
	}
	}
