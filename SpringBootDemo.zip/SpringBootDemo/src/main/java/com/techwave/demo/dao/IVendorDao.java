package com.techwave.demo.dao;

import java.time.LocalDate;
import java.util.List;

import com.techwave.demo.Model.Vendordb;

public interface IVendorDao {
	List<Vendordb> getallVendors();

	Vendordb getByVendorId(int vendorId);

	String DeleteVendor(Vendordb vendordb);

	String UpdateVendor(Vendordb V, int vendorId);

	String InsertVendor(Vendordb V);
	List<Vendordb>getbyVendorName(String name);
	List<Vendordb>getbyDate(LocalDate dor);

}
