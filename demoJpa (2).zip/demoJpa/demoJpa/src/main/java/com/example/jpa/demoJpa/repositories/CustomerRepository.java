package com.example.jpa.demoJpa.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.example.jpa.demoJpa.model.pojo.Customer;
@Repository
public interface CustomerRepository extends JpaRepository<Customer,Integer> {

}
