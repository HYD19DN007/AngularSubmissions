package com.example.jpa.demoJpa.model.dao;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.jpa.demoJpa.model.pojo.Customer;
import com.example.jpa.demoJpa.repositories.CustomerRepository;

@Service
public class CustomerDAO {

	@Autowired
	CustomerRepository customerRepository;
	public List<Customer> GetAllCustomers()
	{
		return customerRepository.findAll();
		
	}
	public Customer insertCustomer(Customer C)
	{
		customerRepository.save(C);
		return C;
	}
	public Customer getCustomerById(int id)
	{
		
		try {
		return customerRepository.findById(id).get();
		}
		catch(NoSuchElementException E)
		{
			return null;
		}
		
		}
	
	
	public Customer updateCustomer(Customer C,int id)
	{
		Customer oldCust=getCustomerById(id);
		if(oldCust!=null)
		{
		oldCust.setCustName(C.getCustName());
		oldCust.setEmail(C.getEmail());
		oldCust.setPhone(C.getPhone());
		
		customerRepository.save(oldCust);
		return C;
		}
		else
			return null;
	}
	
	public Customer deleteCustomer(int id)
	{
		Customer oldCust=getCustomerById(id);
		if(oldCust!=null)
		{
		customerRepository.delete(oldCust);
		return oldCust;
		}
		else
			return null;
	}
	
}
