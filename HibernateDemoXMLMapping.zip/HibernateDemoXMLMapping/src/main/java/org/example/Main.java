package org.example;

import org.example.dao.DbOperations;
import org.example.pojo.Projects;

import java.time.LocalDate;
import java.util.Scanner;

public class Main {
    public static void main(String[] args)
    {
        Scanner S=new Scanner(System.in);
        int pcode=S.nextInt();
        S.nextLine();
        String pdesc =S.nextLine();
        LocalDate stdate=LocalDate.parse(S.nextLine());
        int dur=S.nextInt();
        Projects P=new Projects(pcode,pdesc,stdate,dur);
        String Str= DbOperations.InsertProject(P);
        System.out.println(Str);
    }
}