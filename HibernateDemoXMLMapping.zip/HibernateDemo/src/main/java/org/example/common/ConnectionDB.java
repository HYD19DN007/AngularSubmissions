package org.example.common;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ConnectionDB {
    public static SessionFactory getSessionFactorydetails()
    {
        //access configuration .cfg.xml
        Configuration C =new Configuration();
        C.configure("hibernate.cfg.xml");
        //crete sessionFactory object from Configuration
        SessionFactory factory=C.buildSessionFactory();
        return factory;
    }

}
